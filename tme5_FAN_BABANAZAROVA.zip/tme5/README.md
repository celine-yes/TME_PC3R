# TME5

binômes: FAN Céline 28706052, Babanazarova Dilyara 28709428

Le gestionnaire n'envoie jamais de paquets aux ouvriers.
